﻿using OrderEventService.Model;

namespace OrderEventService.DataStore
{
    public class OrderEventStore : IOrderEventStore
    {
        private Dictionary<int, List<OrderEvent>> _events { get; set; }
        public OrderEventStore()
        {
            _events = new Dictionary<int, List<OrderEvent>>();
        }
        public Task<List<OrderEvent>> GetOrderEventsForTable(int id)
        {
            return Task.FromResult(_events[id]);
        }

        public void PlaceOrder(OrderEvent orderEvent)
        {
            if (!_events.ContainsKey(orderEvent.TableNumber))
            {
                _events.Add(orderEvent.TableNumber, new List<OrderEvent> { orderEvent});
            }
            else
                _events[orderEvent.TableNumber].Add(orderEvent);
        }

        public bool UpdateOrderState(int table, int pizzaNumber, int orderState)
        {
            List<OrderEvent> orders;
             _events.TryGetValue(table, out orders);
            if (orders == null)
            {
                return false;
            }
            OrderEvent? order = orders.Where(x => x.PizzaNumber == pizzaNumber && x.TableNumber == table).FirstOrDefault();
            if (order != null) { 
                order.Status = (OrderStatus)orderState;
                //If order is done - remove it from the eventList, and add it to history (HistoryMicroService?).
                return true;
            }

             return false;
        }
    }
}
