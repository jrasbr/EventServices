﻿using OrderEventService.Model;

namespace OrderEventService.DataStore
{
    public interface IOrderEventStore
    {
        void PlaceOrder(OrderEvent orderEvent);
        Task<List<OrderEvent>> GetOrderEventsForTable(int id);
        bool UpdateOrderState(int table, int pizzaNumber, int orderState);
    }
}
