﻿namespace OrderEventService.Model
{
    public enum OrderStatus 
    {
        Pending, Accepted , Ready, Done
    }

    public class OrderEvent
    {
        public int TableNumber { get; set; }
        public int PizzaNumber { get; set; }

        /// <summary>
        /// Extra salami, no garlic etc.
        /// </summary>
        public string Note { get; set; }

        /// <summary>
        /// 0 = Pending, 1 = Accepted, 2 = Ready, 3 = Done
        /// </summary>
        public OrderStatus Status { get; set; }
    }
}
