﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OrderEventService.DataStore;
using OrderEventService.Model;

namespace OrderEventService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderEventController : ControllerBase
    {
        private readonly IOrderEventStore _orderEventStore;

        public OrderEventController(IOrderEventStore orderEventStore)
        {
            _orderEventStore = orderEventStore;
        }

        [HttpPost("RaiseOrderEvent")]
        public IActionResult RaiseOrderEvent([FromBody] OrderEvent orderEvent)
        {
            _orderEventStore.PlaceOrder(orderEvent);
            return Ok();
        }

        [HttpGet("GetOrdersForTable/{tableNumber}")]
        public IActionResult GetOrdersForTable(int tableNumber)
        {

            List<OrderEvent> orders = Task.Run(()=>_orderEventStore.GetOrderEventsForTable(tableNumber)).Result;

            return Ok(orders);
        }

        [HttpPost("ChangeStatus/{tableNumber}/{pizzaNumber}/{orderState}")]
        public IActionResult ChangeOrderEventStatus(int tableNumber, int pizzaNumber, int orderState)
        {
            bool succes = _orderEventStore.UpdateOrderState(tableNumber, pizzaNumber, orderState);
            if (!succes)
                return StatusCode(StatusCodes.Status404NotFound, "Order not found");
            return Ok();
        }
    }
}
